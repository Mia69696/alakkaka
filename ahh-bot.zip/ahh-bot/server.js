require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const path = require('path');
const { client, state, addLog, addWarning, clearWarnings, addInfraction, createVerifyToken, completeVerification, saveState, createBackup } = require('./bot');

const app = express();
const PORT = process.env.PORT || 3000;
const TOKEN = process.env.BOT_TOKEN;
const DISCORD = 'https://discord.com/api/v10';

// ── AUTH ──────────────────────────────────────────────
const USERS = [
  { username: process.env.DASH_USER || 'foufou',  password: process.env.DASH_PASS || 'fouedben9911' },
  { username: 'yassine', password: 'yassine2010yassine' },
];
const sessions = new Set();

function makeSession() {
  const id = Math.random().toString(36).slice(2) + Date.now().toString(36);
  sessions.add(id);
  return id;
}

function isAuth(req) {
  const cookie = req.headers.cookie || '';
  const match = cookie.match(/session=([^;]+)/);
  return match && sessions.has(match[1]);
}

// ── CORS — allow everything (needed for GitHub Pages) ─
app.use(cors({ origin: '*', methods: ['GET','POST','DELETE','OPTIONS'], allowedHeaders: ['Content-Type','Authorization'] }));
app.options('*', cors());
app.use(express.json());

// ── PUBLIC ROUTES (no login needed) ──────────────────

app.get('/login', (req, res) => {
  if (isAuth(req)) return res.redirect('/');
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (USERS.some(u => u.username === username && u.password === password)) {
    const sid = makeSession();
    res.setHeader('Set-Cookie', `session=${sid}; Path=/; HttpOnly; SameSite=Strict; Max-Age=86400`);
    return res.json({ ok: true });
  }
  res.status(401).json({ ok: false, error: 'wrong username or password' });
});

app.post('/api/logout', (req, res) => {
  const cookie = req.headers.cookie || '';
  const match = cookie.match(/session=([^;]+)/);
  if (match) sessions.delete(match[1]);
  res.setHeader('Set-Cookie', 'session=; Path=/; Max-Age=0');
  res.json({ ok: true });
});

// ── VERIFY ROUTES (fully public — no login) ───────────

app.get('/verify', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'verify.html'));
});

app.post('/api/verify/generate', (req, res) => {
  const { userId, guildId } = req.body;
  if (!userId || !guildId) return res.status(400).json({ ok: false, error: 'userId and guildId required' });
  const token = createVerifyToken(userId, guildId);
  const link = 'https://mia69696.github.io/verify/?token=' + token;
  res.json({ ok: true, token, link });
});

app.post('/api/verify/complete', async (req, res) => {
  const { token } = req.body;
  if (!token) return res.status(400).json({ ok: false, error: 'token required' });
  const result = await completeVerification(token);
  if (!result.ok) addLog('VERIFY', 'failed: ' + result.error, 'red');
  res.json(result);
});

app.get('/api/verify/settings', (req, res) => {
  res.json({
    verificationEnabled: state.verificationEnabled,
    verifiedRoleId: state.verifiedRoleId,
    unverifiedRoleId: state.unverifiedRoleId,
    verificationChannelId: state.verificationChannelId,
    verifyMessageId: state.verifyMessageId,
    verifyEmoji: state.verifyEmoji,
  });
});

app.post('/api/verify/settings', (req, res) => {
  const { verificationEnabled, verifiedRoleId, unverifiedRoleId, verificationChannelId, verifyEmoji } = req.body;
  if (verificationEnabled !== undefined) state.verificationEnabled = verificationEnabled;
  if (verifiedRoleId !== undefined) state.verifiedRoleId = verifiedRoleId;
  if (unverifiedRoleId !== undefined) state.unverifiedRoleId = unverifiedRoleId;
  if (verificationChannelId !== undefined) state.verificationChannelId = verificationChannelId;
  if (verifyEmoji !== undefined) state.verifyEmoji = verifyEmoji;
  saveState();
  addLog('DASH', 'verification settings saved', 'blue');
  res.json({ ok: true });
});

app.get('/api/verify/check/:token', (req, res) => {
  const data = state.pendingVerifications[req.params.token];
  if (!data) return res.json({ valid: false, reason: 'token not found or already used' });
  if (Date.now() > data.expires) return res.json({ valid: false, reason: 'token expired' });
  res.json({
    valid: true,
    userId: data.userId,
    guildId: data.guildId,
    roleId: data.roleId || state.verifiedRoleId || null,
    roleConfigured: !!(data.roleId || state.verifiedRoleId),
    expiresIn: Math.floor((data.expires - Date.now()) / 1000) + 's',
  });
});

app.get('/verify-start', (req, res) => {
  const { guild } = req.query;
  res.redirect('https://mia69696.github.io/verify/?guild=' + (guild || ''));
});

// ── AUTH MIDDLEWARE — protects everything below ───────
app.use((req, res, next) => {
  if (!isAuth(req)) return res.redirect('/login');
  next();
});

app.use(express.static(path.join(__dirname, 'public')));

// ── DISCORD API HELPER ────────────────────────────────
async function dapi(endpoint) {
  const r = await fetch(DISCORD + endpoint, {
    headers: { Authorization: 'Bot ' + TOKEN, 'Content-Type': 'application/json' }
  });
  const txt = await r.text();
  try { return JSON.parse(txt); } catch { return { error: txt }; }
}

// ── BOT INFO ──────────────────────────────────────────
app.get('/api/bot', async (req, res) => {
  try {
    const t0 = Date.now();
    const d = await dapi('/users/@me');
    res.json({ ...d, _ping: Date.now() - t0, _wsPing: client.ws?.ping || 0 });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── GUILDS ────────────────────────────────────────────
app.get('/api/guilds', async (req, res) => {
  try {
    const guilds = await dapi('/users/@me/guilds');
    if (!Array.isArray(guilds)) return res.json(guilds);
    const detailed = await Promise.all(guilds.map(async g => {
      try {
        const full = await dapi('/guilds/' + g.id + '?with_counts=true');
        return { id: g.id, name: g.name, icon: g.icon, owner: g.owner, member_count: full.approximate_member_count || 0, presence_count: full.approximate_presence_count || 0 };
      } catch { return { id: g.id, name: g.name, icon: g.icon, owner: g.owner, member_count: 0 }; }
    }));
    res.json(detailed);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/guilds/:id/members', async (req, res) => {
  try { res.json(await dapi('/guilds/' + req.params.id + '/members?limit=100')); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/guilds/:id/channels', async (req, res) => {
  try { res.json(await dapi('/guilds/' + req.params.id + '/channels')); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/guilds/:id/roles', async (req, res) => {
  try { res.json(await dapi('/guilds/' + req.params.id + '/roles')); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// ── SETTINGS ──────────────────────────────────────────
app.get('/api/settings', (req, res) => {
  res.json({
    blockInvites: state.blockInvites, blockSpam: state.blockSpam,
    badWordsFilter: state.badWordsFilter, blockMassMentions: state.blockMassMentions,
    capsFilter: state.capsFilter, blockLinks: state.blockLinks,
    welcomeEnabled: state.welcomeEnabled, goodbyeEnabled: state.goodbyeEnabled,
    levelingEnabled: state.levelingEnabled, ticketsEnabled: state.ticketsEnabled,
    welcomeMessage: state.welcomeMessage, goodbyeMessage: state.goodbyeMessage,
    levelUpMessage: state.levelUpMessage, welcomeChannelId: state.welcomeChannelId,
    logChannelId: state.logChannelId, autobanThreshold: state.autobanThreshold,
    prefix: state.prefix, muteMinutes: state.muteMinutes, badWordsList: state.badWordsList,
    logChannels: state.logChannels,
  });
});

// get/save log channels specifically
app.get('/api/logchannels', (req, res) => res.json(state.logChannels));

app.post('/api/logchannels', (req, res) => {
  const keys = ['deletedMessages','editedMessages','joinLeave','modActions','commands','images','voiceActivity','roleChanges'];
  keys.forEach(k => { if (req.body[k] !== undefined) state.logChannels[k] = req.body[k] || null; });
  saveState();
  addLog('DASH', 'log channels updated', 'blue');
  res.json({ ok: true });
});

app.post('/api/settings', (req, res) => {
  const allowed = ['blockInvites','blockSpam','badWordsFilter','blockMassMentions','capsFilter','blockLinks',
    'welcomeEnabled','goodbyeEnabled','levelingEnabled','ticketsEnabled','welcomeMessage','goodbyeMessage',
    'levelUpMessage','welcomeChannelId','logChannelId','autobanThreshold','prefix','muteMinutes','badWordsList','logChannels'];
  allowed.forEach(k => { if (req.body[k] !== undefined) state[k] = req.body[k]; });
  saveState();
  addLog('DASH', 'settings updated', 'blue');
  res.json({ ok: true });
});

app.post('/api/toggle', (req, res) => {
  const { key, value } = req.body;
  const allowed = ['blockInvites','blockSpam','badWordsFilter','blockMassMentions','capsFilter','blockLinks',
    'welcomeEnabled','goodbyeEnabled','levelingEnabled','ticketsEnabled','verificationEnabled'];
  if (!allowed.includes(key)) return res.status(400).json({ error: 'invalid key' });
  state[key] = value;
  saveState();
  addLog('DASH', key + ' → ' + value, value ? 'green' : 'yellow');
  res.json({ ok: true, [key]: state[key] });
});

// ── ACTIONS ───────────────────────────────────────────
app.post('/api/action/ban', async (req, res) => {
  const { guildId, userId, reason } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in that server' });
    await guild.members.ban(userId, { reason: reason || 'banned from dashboard' });
    addInfraction(userId, 'ban', reason || 'dashboard ban');
    addLog('MOD', userId + ' banned from dashboard', 'red');
    saveState();
    res.json({ ok: true, message: 'user banned' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/action/kick', async (req, res) => {
  const { guildId, userId, reason } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in that server' });
    const member = await guild.members.fetch(userId);
    await member.kick(reason || 'kicked from dashboard');
    addInfraction(userId, 'kick', reason || 'dashboard kick');
    addLog('MOD', userId + ' kicked from dashboard', 'red');
    saveState();
    res.json({ ok: true, message: 'user kicked' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/action/timeout', async (req, res) => {
  const { guildId, userId, minutes, reason } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in that server' });
    const member = await guild.members.fetch(userId);
    await member.timeout((minutes || 10) * 60000, reason || 'timeout from dashboard');
    addInfraction(userId, 'timeout', reason || 'dashboard timeout');
    addLog('MOD', userId + ' timed out from dashboard', 'yellow');
    saveState();
    res.json({ ok: true, message: 'timed out' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/action/warn', async (req, res) => {
  const { guildId, userId, reason } = req.body;
  try {
    const count = addWarning(guildId, userId);
    addInfraction(userId, 'warn', reason || 'dashboard warn');
    addLog('MOD', userId + ' warned (' + count + ')', 'yellow');
    saveState();
    res.json({ ok: true, warnings: count, message: 'warned' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/action/unban', async (req, res) => {
  const { guildId, userId } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in that server' });
    await guild.members.unban(userId);
    addLog('MOD', userId + ' unbanned', 'green');
    res.json({ ok: true, message: 'unbanned' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/action/clearwarnings', (req, res) => {
  const { guildId, userId } = req.body;
  clearWarnings(guildId, userId);
  addLog('MOD', 'warnings cleared for ' + userId, 'green');
  saveState();
  res.json({ ok: true });
});

app.post('/api/action/send-message', async (req, res) => {
  const { guildId, channelId, message } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in that server' });
    const channel = guild.channels.cache.get(channelId);
    if (!channel) return res.status(404).json({ error: 'channel not found' });
    await channel.send(message);
    addLog('DASH', 'message sent to #' + channel.name, 'blue');
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/action/purge', async (req, res) => {
  const { guildId, channelId, amount } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in that server' });
    const channel = guild.channels.cache.get(channelId);
    if (!channel) return res.status(404).json({ error: 'channel not found' });
    const deleted = await channel.bulkDelete(Math.min(amount || 10, 100), true);
    addLog('MOD', deleted.size + ' messages purged', 'yellow');
    res.json({ ok: true, deleted: deleted.size });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/verify/send-panel', async (req, res) => {
  const { guildId, channelId } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in that server' });
    const channel = guild.channels.cache.get(channelId);
    if (!channel) return res.status(404).json({ error: 'channel not found' });
    const { EmbedBuilder } = require('discord.js');
    const emoji = state.verifyEmoji || '✅';

    const embed = new EmbedBuilder()
      .setColor(0x00e87a)
      .setTitle(emoji + '  verify to get access')
      .setDescription(
        '> react with ' + emoji + ' below to instantly get the verified role and access all channels.' +
        '\n\n' +
        '**how it works:**\n' +
        '1. React with ' + emoji + ' to this message\n' +
        '2. Bot gives you the **@verified** role\n' +
        '3. Your **@unverified** role gets removed\n' +
        '4. You now have full access!'
      )
      .addFields(
        { name: '⚡ instant', value: 'role assigned in seconds', inline: true },
        { name: '🔒 automatic', value: 'no forms needed', inline: true },
        { name: '✅ required', value: 'to access channels', inline: true },
      )
      .setFooter({ text: 'fa11en · just react to verify' })
      .setTimestamp();

    const msg = await channel.send({ embeds: [embed] });

    // add the reaction so users know what to click
    await msg.react(emoji);

    // save the message id so the bot knows which message to watch
    state.verifyMessageId = msg.id;
    saveState();

    addLog('VERIFY', 'reaction verify panel posted in #' + channel.name, 'green');
    res.json({ ok: true, messageId: msg.id });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── DATA ──────────────────────────────────────────────
app.get('/api/infractions', (req, res) => res.json(state.infractions));
app.delete('/api/infractions/:id', (req, res) => {
  state.infractions = state.infractions.filter(i => i.id !== parseInt(req.params.id));
  saveState(); res.json({ ok: true });
});
app.delete('/api/infractions', (req, res) => { state.infractions = []; saveState(); res.json({ ok: true }); });
app.get('/api/logs', (req, res) => res.json(state.logs));
app.delete('/api/logs', (req, res) => { state.logs = []; res.json({ ok: true }); });
app.get('/api/leaderboard', (req, res) => {
  const sorted = Object.entries(state.xpData)
    .sort((a, b) => b[1].level - a[1].level || b[1].xp - a[1].xp)
    .slice(0, 20).map(([id, d]) => ({ id, ...d }));
  res.json(sorted);
});
app.get('/api/stats', (req, res) => {
  res.json({
    totalInfractions: state.infractions.length,
    totalLogs: state.logs.length,
    totalXPUsers: Object.keys(state.xpData).length,
    totalTickets: state.ticketCount,
    wsPing: client.ws?.ping || 0,
  });
});

// ── TEMP VOICE API ───────────────────────────────────

app.get('/api/tempvoice/settings', (req, res) => {
  res.json({
    tempVoiceEnabled: state.tempVoiceEnabled,
    tempVoiceCategoryId: state.tempVoiceCategoryId,
    tempVoiceCreatorId: state.tempVoiceCreatorId,
    tempVoiceControlChannelId: state.tempVoiceControlChannelId,
    activeChannels: Object.entries(state.tempVoiceChannels).map(([id, d]) => ({ id, ...d })),
  });
});

app.post('/api/tempvoice/settings', (req, res) => {
  const { tempVoiceEnabled, tempVoiceCategoryId, tempVoiceCreatorId, tempVoiceControlChannelId } = req.body;
  if (tempVoiceEnabled !== undefined) state.tempVoiceEnabled = tempVoiceEnabled;
  if (tempVoiceCategoryId !== undefined) state.tempVoiceCategoryId = tempVoiceCategoryId || null;
  if (tempVoiceCreatorId !== undefined) state.tempVoiceCreatorId = tempVoiceCreatorId || null;
  if (tempVoiceControlChannelId !== undefined) state.tempVoiceControlChannelId = tempVoiceControlChannelId || null;
  saveState();
  addLog('DASH', 'temp voice settings saved', 'blue');
  res.json({ ok: true });
});

// setup: create the "join to create" channel automatically
app.post('/api/tempvoice/setup', async (req, res) => {
  const { guildId } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in that server' });

    // create category
    const category = await guild.channels.create({
      name: '🔊 Temp Voice',
      type: 4, // category
    });

    // create join-to-create channel
    const creator = await guild.channels.create({
      name: '➕ Join to Create',
      type: 2, // voice
      parent: category.id,
    });

    // create control text channel
    const controlCh = await guild.channels.create({
      name: '🎛️-vc-controls',
      type: 0, // text
      parent: category.id,
      topic: 'control your temp voice channel here',
    });

    state.tempVoiceCategoryId = category.id;
    state.tempVoiceCreatorId = creator.id;
    state.tempVoiceControlChannelId = controlCh.id;
    state.tempVoiceEnabled = true;
    saveState();
    addLog('DASH', 'temp voice setup complete in ' + guild.name, 'green');
    res.json({ ok: true, categoryId: category.id, creatorId: creator.id, controlChannelId: controlCh.id });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// control a specific temp voice channel from dashboard
app.post('/api/tempvoice/control', async (req, res) => {
  const { guildId, channelId, action, value } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in that server' });
    const channel = guild.channels.cache.get(channelId);
    if (!channel) return res.status(404).json({ error: 'channel not found' });

    if (action === 'rename') {
      await channel.setName(value);
      if (state.tempVoiceChannels[channelId]) state.tempVoiceChannels[channelId].name = value;
    } else if (action === 'limit') {
      await channel.setUserLimit(parseInt(value) || 0);
      if (state.tempVoiceChannels[channelId]) state.tempVoiceChannels[channelId].limit = parseInt(value) || 0;
    } else if (action === 'lock') {
      await channel.permissionOverwrites.edit(guild.id, { Connect: false });
    } else if (action === 'unlock') {
      await channel.permissionOverwrites.edit(guild.id, { Connect: true });
    } else if (action === 'delete') {
      delete state.tempVoiceChannels[channelId];
      await channel.delete('deleted from dashboard');
    } else if (action === 'kick') {
      const member = guild.members.cache.get(value);
      if (member?.voice?.channelId === channelId) await member.voice.disconnect();
    }

    addLog('VOICE', 'temp vc ' + action + ' on #' + channel.name + ' from dashboard', 'cyan');
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── EXTENDED SETTINGS ────────────────────────────────
app.post('/api/settings/welcome', (req, res) => {
  const fields = ['welcomeGif','goodbyeGif','ticketGif','welcomeChannelId','goodbyeChannelId','welcomeMessage','goodbyeMessage','welcomeEnabled','goodbyeEnabled','welcomeCardText','welcomeCardSub','welcomeCardCircleColor','welcomeCardOverlay','goodbyeCardText','goodbyeCardSub','goodbyeCardCircleColor','goodbyeChannelId'];
  fields.forEach(k => { if (req.body[k] !== undefined) state[k] = req.body[k] === '' ? null : req.body[k]; });
  saveState();
  res.json({ ok: true });
});

app.get('/api/settings/welcome', (req, res) => {
  res.json({
    welcomeGif: state.welcomeGif, goodbyeGif: state.goodbyeGif, ticketGif: state.ticketGif,
    welcomeChannelId: state.welcomeChannelId, goodbyeChannelId: state.goodbyeChannelId,
    welcomeMessage: state.welcomeMessage, goodbyeMessage: state.goodbyeMessage,
    welcomeEnabled: state.welcomeEnabled, goodbyeEnabled: state.goodbyeEnabled,
    welcomeCardText: state.welcomeCardText, welcomeCardSub: state.welcomeCardSub,
    welcomeCardCircleColor: state.welcomeCardCircleColor || '#ffffff',
    welcomeCardOverlay: state.welcomeCardOverlay !== undefined ? state.welcomeCardOverlay : 0.45,
    goodbyeCardText: state.goodbyeCardText, goodbyeCardSub: state.goodbyeCardSub,
    goodbyeCardCircleColor: state.goodbyeCardCircleColor || '#ff3555',
  });
});

// ── REACTION ROLES ────────────────────────────────────
app.get('/api/reactionroles', (req, res) => res.json(state.reactionRoles || {}));

app.post('/api/reactionroles/create', async (req, res) => {
  const { guildId, channelId, emoji, roleId, description, allPairs } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in server' });
    const channel = guild.channels.cache.get(channelId);
    if (!channel) return res.status(404).json({ error: 'channel not found' });
    const { EmbedBuilder } = require('discord.js');
    const embed = new EmbedBuilder()
      .setColor(0x5865f2)
      .setTitle('🎭 reaction roles')
      .setDescription((description || 'react to get a role') + '\n\n' + (allPairs && allPairs.length ? allPairs.map(p => p.emoji + ' → <@&' + p.roleId + '>').join('\n') : emoji + ' → <@&' + roleId + '>') )
      .setFooter({ text: 'fa11en · react to assign role' })
      .setTimestamp();
    const msg = await channel.send({ embeds: [embed] });
    await msg.react(emoji);
    if (!state.reactionRoles) state.reactionRoles = {};
    if (!state.reactionRoles[msg.id]) state.reactionRoles[msg.id] = { guildId, channelId, roles: {} };
    state.reactionRoles[msg.id].roles[emoji] = roleId;
    saveState();
    addLog('ROLE', 'reaction role created in #' + channel.name, 'green');
    res.json({ ok: true, messageId: msg.id });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/reactionroles/add', async (req, res) => {
  const { messageId, guildId, channelId, emoji, roleId } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    const channel = guild?.channels.cache.get(channelId);
    const msg = await channel?.messages.fetch(messageId);
    if (!msg) return res.status(404).json({ error: 'message not found' });
    await msg.react(emoji);
    if (!state.reactionRoles[messageId]) state.reactionRoles[messageId] = { guildId, channelId, roles: {} };
    state.reactionRoles[messageId].roles[emoji] = roleId;
    saveState();
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/reactionroles/:msgId', async (req, res) => {
  const { msgId } = req.params;
  const rr = state.reactionRoles?.[msgId];
  if (rr) {
    try {
      const guild = client.guilds.cache.get(rr.guildId);
      const channel = guild?.channels.cache.get(rr.channelId);
      const msg = await channel?.messages.fetch(msgId).catch(() => null);
      if (msg) await msg.delete();
    } catch(e) {}
    delete state.reactionRoles[msgId];
    saveState();
  }
  res.json({ ok: true });
});

// ── SERVER BACKUP ─────────────────────────────────────
app.get('/api/backup/:guildId', (req, res) => {
  const backups = state.serverBackups?.[req.params.guildId] || [];
  res.json(backups);
});

app.post('/api/backup/create', async (req, res) => {
  const { guildId, name } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in server' });
    const backup = await createBackup(guild, name);
    addLog('DASH', 'server backup created for ' + guild.name + ' — ' + backup.roles.length + ' roles, ' + backup.channels.length + ' channels', 'green');
    res.json({ ok: true, backup });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// get all backups across all servers
app.get('/api/backup/all', (req, res) => {
  const result = [];
  Object.entries(state.serverBackups || {}).forEach(([guildId, backups]) => {
    backups.forEach((b, i) => {
      result.push({ ...b, guildId, index: i });
    });
  });
  result.sort((a, b) => new Date(b.date) - new Date(a.date));
  res.json(result);
});

app.delete('/api/backup/:guildId/:index', (req, res) => {
  const { guildId, index } = req.params;
  if (state.serverBackups?.[guildId]) {
    state.serverBackups[guildId].splice(parseInt(index), 1);
    saveState();
  }
  res.json({ ok: true });
});

// ── AUTOMOD EXTENDED ──────────────────────────────────
app.post('/api/automod/settings', (req, res) => {
  const allowed = ['blockInvites','blockSpam','badWordsFilter','blockMassMentions','capsFilter',
    'blockLinks','blockDuplicates','blockEmojiSpam','blockMentionSpam','emojiSpamLimit','mentionSpamLimit','autobanThreshold','muteMinutes'];
  allowed.forEach(k => { if (req.body[k] !== undefined) state[k] = req.body[k]; });
  saveState();
  addLog('DASH','automod settings updated','blue');
  res.json({ ok: true });
});


// ── TICKET SETTINGS ──────────────────────────────────
app.get('/api/ticket/settings', (req, res) => {
  res.json({
    ticketsEnabled: state.ticketsEnabled,
    ticketGif: state.ticketGif || null,
    ticketTitle: state.ticketTitle || 'Staff Support',
    ticketDescription: state.ticketDescription || 'Contact our staff team privately so we can assist you with whatever you need.',
    ticketPanelChannelId: state.ticketPanelChannelId || null,
  });
});

app.post('/api/ticket/settings', (req, res) => {
  const { ticketGif, ticketTitle, ticketDescription } = req.body;
  if (ticketGif !== undefined) state.ticketGif = ticketGif || null;
  if (ticketTitle !== undefined) state.ticketTitle = ticketTitle || 'Staff Support';
  if (ticketDescription !== undefined) state.ticketDescription = ticketDescription || null;
  saveState();
  res.json({ ok: true });
});

app.post('/api/ticket/send-panel', async (req, res) => {
  const { guildId, channelId } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in server' });
    const channel = guild.channels.cache.get(channelId);
    if (!channel) return res.status(404).json({ error: 'channel not found' });
    const { EmbedBuilder } = require('discord.js');
    const botAvatar = client.user.displayAvatarURL({ dynamic: true, size: 512 });
    const title = state.ticketTitle || 'Staff Support';
    const desc = state.ticketDescription || 'Contact our staff team privately so we can assist you with whatever you need.';
    const embed = new EmbedBuilder()
      .setColor(0x2b2d31)
      .setAuthor({ name: title, iconURL: botAvatar })
      .setTitle('Do you need help with something?')
      .setDescription(desc)
      .setThumbnail(botAvatar)
      .setFooter({ text: 'fa11en support system', iconURL: botAvatar })
      .setTimestamp();
    if (state.ticketGif) embed.setImage(state.ticketGif);
    await channel.send({
      embeds: [embed],
      components: [{ type: 1, components: [{ type: 2, style: 1, label: 'Create Ticket', emoji: '🎫', custom_id: 'open_ticket' }] }]
    });
    state.ticketPanelChannelId = channelId;
    saveState();
    addLog('TICKET', 'ticket panel sent to #' + channel.name, 'cyan');
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── BACKUP RESTORE ────────────────────────────────────
app.post('/api/backup/restore', async (req, res) => {
  const { guildId, sourceGuildId, index } = req.body;
  // load backup from sourceGuildId (where it was saved) into guildId (target server)
  const targetGuildId = guildId;
  const backupGuildId = sourceGuildId || guildId;
  try {
    const guild = client.guilds.cache.get(targetGuildId);
    if (!guild) return res.status(404).json({ error: 'bot not in target server' });
    const backups = state.serverBackups?.[backupGuildId];
    if (!backups || !backups[index]) return res.status(404).json({ error: 'backup not found' });
    const backup = backups[index];
    const results = { rolesCreated: 0, channelsCreated: 0, errors: [] };
    // restore roles (skip @everyone and managed roles)
    for (const role of backup.roles.sort((a,b) => a.position - b.position)) {
      try {
        const exists = guild.roles.cache.find(r => r.name === role.name);
        if (!exists) {
          await guild.roles.create({ name: role.name, color: role.color, hoist: role.hoist, mentionable: role.mentionable, permissions: BigInt(role.permissions || '0') });
          results.rolesCreated++;
        }
      } catch(e) { results.errors.push('role '+role.name+': '+e.message); }
    }
    // restore channels (categories first, then others)
    const sorted = [...backup.channels].sort((a,b) => (a.type===4?-1:1));
    for (const ch of sorted) {
      try {
        const exists = guild.channels.cache.find(c => c.name === ch.name && c.type === ch.type);
        if (!exists) {
          const opts = { name: ch.name, type: ch.type };
          if (ch.topic) opts.topic = ch.topic;
          await guild.channels.create(opts);
          results.channelsCreated++;
        }
      } catch(e) { results.errors.push('channel '+ch.name+': '+e.message); }
    }
    addLog('DASH', 'backup loaded into '+guild.name+' — '+results.rolesCreated+' roles, '+results.channelsCreated+' channels created', 'green');
    res.json({ ok: true, ...results });
  } catch(e) { res.status(500).json({ error: e.message }); }
});


// ── SECURITY SETTINGS ────────────────────────────────
app.get('/api/security', (req, res) => {
  res.json({
    antiRaidEnabled: state.antiRaidEnabled, antiRaidThreshold: state.antiRaidThreshold,
    antiRaidWindow: state.antiRaidWindow, antiRaidAction: state.antiRaidAction,
    altDetectEnabled: state.altDetectEnabled, altDetectDays: state.altDetectDays,
    altDetectAction: state.altDetectAction, altDetectLogChannel: state.altDetectLogChannel,
    autoRoleEnabled: state.autoRoleEnabled, autoRoleId: state.autoRoleId, autoRoleDelay: state.autoRoleDelay,
    nicknameFilterEnabled: state.nicknameFilterEnabled, nicknameFilterWords: state.nicknameFilterWords,
    muteRoleId: state.muteRoleId,
  });
});

app.post('/api/security', (req, res) => {
  const allowed = ['antiRaidEnabled','antiRaidThreshold','antiRaidWindow','antiRaidAction',
    'altDetectEnabled','altDetectDays','altDetectAction','altDetectLogChannel',
    'autoRoleEnabled','autoRoleId','autoRoleDelay','nicknameFilterEnabled','nicknameFilterWords','muteRoleId'];
  allowed.forEach(k => { if (req.body[k] !== undefined) state[k] = req.body[k]; });
  saveState();
  addLog('DASH', 'security settings updated', 'blue');
  res.json({ ok: true });
});

// ── CUSTOM COMMANDS ───────────────────────────────────
app.get('/api/customcommands', (req, res) => res.json(state.customCommands || {}));

app.post('/api/customcommands', (req, res) => {
  const { trigger, response } = req.body;
  if (!trigger || !response) return res.status(400).json({ error: 'trigger and response required' });
  if (!state.customCommands) state.customCommands = {};
  state.customCommands[trigger.toLowerCase().trim()] = response.trim();
  saveState();
  addLog('DASH', 'custom command added: ' + trigger, 'green');
  res.json({ ok: true });
});

app.delete('/api/customcommands/:trigger', (req, res) => {
  const t = decodeURIComponent(req.params.trigger);
  if (state.customCommands) delete state.customCommands[t];
  saveState();
  res.json({ ok: true });
});

// ── SLOWMODE ──────────────────────────────────────────
app.post('/api/slowmode', async (req, res) => {
  const { guildId, channelId, seconds } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    const channel = guild?.channels.cache.get(channelId);
    if (!channel) return res.status(404).json({ error: 'channel not found' });
    await channel.setRateLimitPerUser(parseInt(seconds) || 0);
    if (!state.slowmodeChannels) state.slowmodeChannels = {};
    if (seconds > 0) state.slowmodeChannels[channelId] = parseInt(seconds);
    else delete state.slowmodeChannels[channelId];
    saveState();
    addLog('MOD', 'slowmode set to ' + seconds + 's in #' + channel.name, 'yellow');
    res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── ADVANCED LOG CHANNELS ────────────────────────────
app.get('/api/logchannels/extra', (req, res) => res.json(state.logChannelsExtra || {}));

app.post('/api/logchannels/extra', (req, res) => {
  if (!state.logChannelsExtra) state.logChannelsExtra = {};
  const allowed = ['nicknameChanges','inviteCreated','inviteDeleted','messagesBulkDelete',
    'stageEvents','threadCreated','threadDeleted','boostEvents','emojiCreated','emojiDeleted','webhookChanges'];
  allowed.forEach(k => { if (req.body[k] !== undefined) state.logChannelsExtra[k] = req.body[k] || null; });
  saveState();
  addLog('DASH', 'advanced log channels updated', 'blue');
  res.json({ ok: true });
});

// ── LOCK/UNLOCK SERVER (anti-raid manual) ────────────
app.post('/api/security/lockdown', async (req, res) => {
  const { guildId, lock } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in server' });
    const { PermissionFlagsBits } = require('discord.js');
    let count = 0;
    for (const [, channel] of guild.channels.cache) {
      if (channel.type !== 0) continue;
      try {
        await channel.permissionOverwrites.edit(guild.id, { SendMessages: lock ? false : null });
        count++;
      } catch(e) {}
    }
    state.antiRaidLocked = !!lock;
    addLog('SECURITY', (lock ? 'SERVER LOCKED DOWN' : 'server unlocked') + ' — ' + count + ' channels', lock ? 'red' : 'green');
    res.json({ ok: true, channelsAffected: count });
  } catch(e) { res.status(500).json({ error: e.message }); }
});


// ── CONFIG EXPORT / IMPORT ────────────────────────────
app.get('/api/config/export', (req, res) => {
  const exportKeys = [
    'blockInvites','blockSpam','badWordsFilter','blockMassMentions','capsFilter','blockLinks',
    'blockDuplicates','blockEmojiSpam','emojiSpamLimit','autobanThreshold','muteMinutes',
    'badWordsList','welcomeEnabled','goodbyeEnabled','levelingEnabled','ticketsEnabled',
    'welcomeMessage','goodbyeMessage','levelUpMessage','welcomeChannelId','goodbyeChannelId',
    'welcomeGif','goodbyeGif','ticketGif','ticketTitle','ticketDescription',
    'logChannelId','logChannels','tempVoiceEnabled','verificationEnabled',
    'verifiedRoleId','unverifiedRoleId','verifyEmoji',
    'antiRaidEnabled','antiRaidThreshold','antiRaidWindow','antiRaidAction',
    'altDetectEnabled','altDetectDays','altDetectAction','altDetectLogChannel',
    'autoRoleEnabled','autoRoleId','autoRoleDelay','nicknameFilterEnabled','nicknameFilterWords',
    'customCommands','reactionRoles',
  ];
  const out = {};
  exportKeys.forEach(k => { if (state[k] !== undefined) out[k] = state[k]; });
  res.json(out);
});

app.post('/api/config/import', (req, res) => {
  const allowed = [
    'blockInvites','blockSpam','badWordsFilter','blockMassMentions','capsFilter','blockLinks',
    'blockDuplicates','blockEmojiSpam','emojiSpamLimit','autobanThreshold','muteMinutes',
    'badWordsList','welcomeEnabled','goodbyeEnabled','levelingEnabled','ticketsEnabled',
    'welcomeMessage','goodbyeMessage','levelUpMessage','welcomeChannelId','goodbyeChannelId',
    'welcomeGif','goodbyeGif','ticketGif','ticketTitle','ticketDescription',
    'logChannelId','logChannels','verificationEnabled','verifiedRoleId','unverifiedRoleId','verifyEmoji',
    'antiRaidEnabled','antiRaidThreshold','antiRaidWindow','antiRaidAction',
    'altDetectEnabled','altDetectDays','altDetectAction','altDetectLogChannel',
    'autoRoleEnabled','autoRoleId','autoRoleDelay','nicknameFilterEnabled','nicknameFilterWords',
    'customCommands',
  ];
  allowed.forEach(k => { if (req.body[k] !== undefined) state[k] = req.body[k]; });
  saveState();
  addLog('DASH', 'config imported from dashboard', 'green');
  res.json({ ok: true });
});

// ── GIVEAWAYS ─────────────────────────────────────────
app.post('/api/giveaway/start', async (req, res) => {
  const { guildId, channelId, prize, endsAt, winners } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    const channel = guild?.channels.cache.get(channelId);
    if (!channel) return res.status(404).json({ error: 'channel not found' });
    const { EmbedBuilder } = require('discord.js');
    const id = 'gw_' + Date.now();
    const embed = new EmbedBuilder()
      .setColor(0xf0b429)
      .setTitle('🎁 GIVEAWAY')
      .setDescription(`**${prize}**\n\nReact with 🎉 to enter!\n\nWinners: **${winners}**\nEnds: <t:${Math.floor(endsAt/1000)}:R>`)
      .setFooter({ text: 'fa11en giveaway · id: ' + id })
      .setTimestamp(new Date(endsAt));
    const msg = await channel.send({ embeds: [embed] });
    await msg.react('🎉');
    if (!state.giveaways) state.giveaways = {};
    state.giveaways[id] = { id, guildId, channelId, messageId: msg.id, prize, endsAt, winners: parseInt(winners)||1, entries: [] };
    saveState();
    setTimeout(() => endGiveawayFn(id), Math.max(endsAt - Date.now(), 1000));
    addLog('DASH', 'giveaway started: ' + prize, 'yellow');
    res.json({ ok: true, id });
  } catch(e) { res.status(500).json({ error: e.message }); }
});
app.get('/api/giveaway/list', (req, res) => {
  const now = Date.now();
  res.json(Object.values(state.giveaways || {}).filter(g => g.endsAt > now));
});
app.post('/api/giveaway/end', async (req, res) => {
  const { giveawayId } = req.body;
  try { const result = await endGiveawayFn(giveawayId); res.json({ ok: true, winners: result }); }
  catch(e) { res.status(500).json({ error: e.message }); }
});
async function endGiveawayFn(id) {
  const gw = state.giveaways?.[id];
  if (!gw || gw.ended) return [];
  try {
    const guild = client.guilds.cache.get(gw.guildId);
    const channel = guild?.channels.cache.get(gw.channelId);
    const msg = await channel?.messages.fetch(gw.messageId).catch(() => null);
    if (msg) {
      const reaction = msg.reactions.cache.get('🎉');
      const users = await reaction?.users.fetch().catch(() => null);
      const entries = users ? [...users.values()].filter(u => !u.bot).map(u => u.id) : [];
      const winners = [];
      const pool = [...entries];
      for (let i = 0; i < Math.min(gw.winners, pool.length); i++) {
        const idx = Math.floor(Math.random() * pool.length);
        winners.push(pool.splice(idx, 1)[0]);
      }
      const { EmbedBuilder } = require('discord.js');
      const embed = new EmbedBuilder()
        .setColor(winners.length ? 0x3ddc84 : 0x444444)
        .setTitle('🎁 GIVEAWAY ENDED')
        .setDescription(`**${gw.prize}**\n\n${winners.length ? 'Winners: ' + winners.map(w => `<@${w}>`).join(', ') : 'No valid entries'}`)
        .setTimestamp();
      await msg.edit({ embeds: [embed] });
      if (winners.length) await channel.send(`Congratulations ${winners.map(w=>`<@${w}>`).join(', ')}! You won **${gw.prize}**! 🎉`);
      gw.entries = entries; gw.winnersList = winners; gw.ended = true;
      saveState();
      addLog('DASH', 'giveaway ended: ' + gw.prize + ' — winner: ' + (winners[0]||'no entries'), 'green');
      return winners;
    }
  } catch(e) { console.error('giveaway end err:', e.message); }
  gw.ended = true; saveState();
  return [];
}

// ── SERVER STATS ──────────────────────────────────────
app.post('/api/serverstats/setup', async (req, res) => {
  const { guildId } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    if (!guild) return res.status(404).json({ error: 'bot not in server' });
    if (!state.serverStats) state.serverStats = {};
    await guild.members.fetch();
    const cat = await guild.channels.create({ name: '── SERVER STATS ──', type: 4, permissionOverwrites: [{ id: guild.id, deny: ['Connect'] }] });
    const memberCh = await guild.channels.create({ name: 'Members: ' + guild.memberCount, type: 2, parent: cat.id, permissionOverwrites: [{ id: guild.id, deny: ['Connect'] }] });
    const botCount = guild.members.cache.filter(m => m.user.bot).size;
    const botCh = await guild.channels.create({ name: 'Bots: ' + botCount, type: 2, parent: cat.id, permissionOverwrites: [{ id: guild.id, deny: ['Connect'] }] });
    const boostCh = await guild.channels.create({ name: 'Boosts: ' + (guild.premiumSubscriptionCount||0), type: 2, parent: cat.id, permissionOverwrites: [{ id: guild.id, deny: ['Connect'] }] });
    state.serverStats[guildId] = { categoryId: cat.id, memberChannelId: memberCh.id, botChannelId: botCh.id, boostChannelId: boostCh.id };
    saveState();
    addLog('DASH', 'server stats channels created in ' + guild.name, 'green');
    res.json({ ok: true, memberChannel: memberCh.id, botChannel: botCh.id, boostChannel: boostCh.id });
  } catch(e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/serverstats/remove', async (req, res) => {
  const { guildId } = req.body;
  try {
    const guild = client.guilds.cache.get(guildId);
    const stats = state.serverStats?.[guildId];
    if (guild && stats) {
      for (const key of ['memberChannelId','botChannelId','boostChannelId','categoryId']) {
        if (stats[key]) { const ch = guild.channels.cache.get(stats[key]); if (ch) await ch.delete().catch(()=>{}); }
      }
    }
    if (state.serverStats) delete state.serverStats[guildId];
    saveState(); res.json({ ok: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/serverstats/settings', (req, res) => {
  const { guildId, memberChannelId, botChannelId, boostChannelId } = req.body;
  if (!state.serverStats) state.serverStats = {};
  if (!state.serverStats[guildId]) state.serverStats[guildId] = {};
  if (memberChannelId) state.serverStats[guildId].memberChannelId = memberChannelId;
  if (botChannelId) state.serverStats[guildId].botChannelId = botChannelId;
  if (boostChannelId) state.serverStats[guildId].boostChannelId = boostChannelId;
  saveState(); res.json({ ok: true });
});
setInterval(async () => {
  if (!state.serverStats) return;
  for (const [guildId, stats] of Object.entries(state.serverStats)) {
    try {
      const guild = client.guilds.cache.get(guildId);
      if (!guild) continue;
      await guild.members.fetch().catch(()=>{});
      const memberCh = guild.channels.cache.get(stats.memberChannelId);
      const botCh = guild.channels.cache.get(stats.botChannelId);
      const boostCh = guild.channels.cache.get(stats.boostChannelId);
      if (memberCh) await memberCh.setName('Members: ' + guild.memberCount).catch(()=>{});
      if (botCh) await botCh.setName('Bots: ' + guild.members.cache.filter(m=>m.user.bot).size).catch(()=>{});
      if (boostCh) await boostCh.setName('Boosts: ' + (guild.premiumSubscriptionCount||0)).catch(()=>{});
    } catch(e) {}
  }
}, 10 * 60 * 1000);

// ── SCHEDULER ─────────────────────────────────────────
app.post('/api/scheduler/add', (req, res) => {
  const { guildId, channelId, message, sendAt, repeat } = req.body;
  if (!state.scheduledMessages) state.scheduledMessages = [];
  const id = 'sched_' + Date.now();
  const item = { id, guildId, channelId, message, sendAt: parseInt(sendAt), repeat: repeat||'none' };
  state.scheduledMessages.push(item);
  saveState(); schedMsg(item);
  addLog('DASH', 'message scheduled for ' + new Date(sendAt).toLocaleString(), 'blue');
  res.json({ ok: true, id });
});
app.get('/api/scheduler/list', (req, res) => {
  res.json((state.scheduledMessages||[]).filter(s => !s.done));
});
app.post('/api/scheduler/delete', (req, res) => {
  const { id } = req.body;
  if (state.scheduledMessages) state.scheduledMessages = state.scheduledMessages.filter(s => s.id !== id);
  saveState(); res.json({ ok: true });
});
function schedMsg(item) {
  const delay = item.sendAt - Date.now();
  if (delay < 0) return;
  setTimeout(async () => {
    try {
      const guild = client.guilds.cache.get(item.guildId);
      const channel = guild?.channels.cache.get(item.channelId);
      if (channel) { await channel.send(item.message); addLog('SCHED', 'scheduled message sent in ' + guild.name, 'green'); }
      if (item.repeat === 'daily') { item.sendAt += 86400000; saveState(); schedMsg(item); }
      else if (item.repeat === 'weekly') { item.sendAt += 7*86400000; saveState(); schedMsg(item); }
      else { item.done = true; saveState(); }
    } catch(e) { console.error('scheduler err:', e.message); item.done = true; saveState(); }
  }, delay);
}
setTimeout(() => {
  (state.scheduledMessages||[]).filter(s => !s.done && s.sendAt > Date.now()).forEach(schedMsg);
}, 3000);

// ── FALLBACK ──────────────────────────────────────────
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, '0.0.0.0', () => console.log('fa11en dashboard on port ' + PORT));
